Python 3.12.4 (tags/v3.12.4:8e8a4ba, Jun  6 2024, 19:30:16) [MSC v.1940 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.

= RESTART: C:/Users/kunda/Desktop/61/python project 61.py
enter number of packages:20
enter the tourid:161
enter the source:bangalore
enter the destination:pondi
enter the days:4
enter the distance:500
enter the packagecost:5000
enter the tourid:121
enter the source:chennai
enter the destination:mumbai
enter the days:6
enter the distance:600
enter the packagecost:2000
enter the tourid:131
enter the source:ongole
enter the destination:hyd
enter the days:7
enter the distance:500
enter the packagecost:3000
enter the tourid:171
enter the source:vij
enter the destination:ongole
enter the days:3
enter the distance:300
enter the packagecost:2678
enter the tourid:141
enter the source:pondi
enter the destination:goa
enter the days:3
enter the distance:200
enter the packagecost:12345
enter the tourid:131
enter the source:rajamundary
enter the destination:goa
enter the days:5
enter the distance:356
enter the packagecost:23456
enter the tourid:444
enter the source:ong
enter the destination:goa
enter the days:5
enter the distance:356
enter the packagecost:23456
enter the tourid:444
enter the source:ong
enter the destination:goa
enter the days:4
enter the distance:299
enter the packagecost:4400
enter the tourid:667
enter the source:hyd
enter the destination:mumbai
enter the days:8
enter the distance:600
enter the packagecost:6640
enter the tourid:876
enter the source:guntur
enter the destination:lucknow
enter the days:5
enter the distance:6000
enter the packagecost:4599
enter the tourid:756
enter the source:goa
enter the destination:manipur
enter the days:4
enter the distance:590
enter the packagecost:67000
enter the tourid:234
enter the source:delhi
enter the destination:hyd
enter the days:3
enter the distance:790
enter the packagecost:55000
enter the tourid:678
enter the source:chennai
enter the destination:ong
enter the days:7
enter the distance:499
enter the packagecost:66000
enter the tourid:500
enter the source:ong
enter the destination:usa
enter the days:9
enter the distance:200000
enter the packagecost:454336
enter the tourid:88
enter the source:hyd
enter the destination:russia
enter the days:8
enter the distance:550000
enter the packagecost:23000
enter the tourid:909
enter the source:ong
enter the destination:manipur
enter the days:9
enter the distance:23400
enter the packagecost:459800
enter the tourid:584
enter the source:vij
enter the destination:kolkata
enter the days:5
enter the distance:453
enter the packagecost:56423
enter the tourid:534
enter the source:ong
enter the destination:asia
enter the days:56
enter the distance:7655
enter the packagecost:5687215
enter the tourid:43
enter the source:russia
enter the destination:germany
enter the days:5
enter the distance:56998
enter the packagecost:57678
enter the tourid:546
enter the source:chennai
enter the destination:paris
enter the days:43
enter the distance:547235487
enter the packagecost:54763
Tourid	source	destination	Days	Distance	Packagecost
{'tourid': 161, 'source': 'bangalore', 'destination': 'pondi', 'days': 4, 'distance': 500, 'packagecost': 5000}
{'tourid': 121, 'source': 'chennai', 'destination': 'mumbai', 'days': 6, 'distance': 600, 'packagecost': 2000}
{'tourid': 131, 'source': 'ongole', 'destination': 'hyd', 'days': 7, 'distance': 500, 'packagecost': 3000}
{'tourid': 171, 'source': 'vij', 'destination': 'ongole', 'days': 3, 'distance': 300, 'packagecost': 2678}
{'tourid': 141, 'source': 'pondi', 'destination': 'goa', 'days': 3, 'distance': 200, 'packagecost': 12345}
{'tourid': 131, 'source': 'rajamundary', 'destination': 'goa', 'days': 5, 'distance': 356, 'packagecost': 23456}
{'tourid': 444, 'source': 'ong', 'destination': 'goa', 'days': 5, 'distance': 356, 'packagecost': 23456}
{'tourid': 444, 'source': 'ong', 'destination': 'goa', 'days': 4, 'distance': 299, 'packagecost': 4400}
{'tourid': 667, 'source': 'hyd', 'destination': 'mumbai', 'days': 8, 'distance': 600, 'packagecost': 6640}
{'tourid': 876, 'source': 'guntur', 'destination': 'lucknow', 'days': 5, 'distance': 6000, 'packagecost': 4599}
{'tourid': 756, 'source': 'goa', 'destination': 'manipur', 'days': 4, 'distance': 590, 'packagecost': 67000}
{'tourid': 234, 'source': 'delhi', 'destination': 'hyd', 'days': 3, 'distance': 790, 'packagecost': 55000}
{'tourid': 678, 'source': 'chennai', 'destination': 'ong', 'days': 7, 'distance': 499, 'packagecost': 66000}
{'tourid': 500, 'source': 'ong', 'destination': 'usa', 'days': 9, 'distance': 200000, 'packagecost': 454336}
{'tourid': 88, 'source': 'hyd', 'destination': 'russia', 'days': 8, 'distance': 550000, 'packagecost': 23000}
{'tourid': 909, 'source': 'ong', 'destination': 'manipur', 'days': 9, 'distance': 23400, 'packagecost': 459800}
{'tourid': 584, 'source': 'vij', 'destination': 'kolkata', 'days': 5, 'distance': 453, 'packagecost': 56423}
{'tourid': 534, 'source': 'ong', 'destination': 'asia', 'days': 56, 'distance': 7655, 'packagecost': 5687215}
{'tourid': 43, 'source': 'russia', 'destination': 'germany', 'days': 5, 'distance': 56998, 'packagecost': 57678}
{'tourid': 546, 'source': 'chennai', 'destination': 'paris', 'days': 43, 'distance': 547235487, 'packagecost': 54763}
enter tour id:171
vij ongole 3 300 2678
enter starting point:vij
2
no.of days:3
0
enter the distance you require above :300
17
20000 60000
range: 7
lowest cost: 121
